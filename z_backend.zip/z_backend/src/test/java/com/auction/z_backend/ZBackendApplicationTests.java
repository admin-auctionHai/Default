package com.auction.z_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
