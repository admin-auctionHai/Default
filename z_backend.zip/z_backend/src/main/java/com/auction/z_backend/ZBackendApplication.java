package com.auction.z_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZBackendApplication.class, args);
	}

}
